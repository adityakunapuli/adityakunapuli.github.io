---
layout: page
title: Computational Statistics
subtitle: Kernel Density Estimation
---



5. Construct kernel density estimates of the data using the Gaussian and Epanechnikov kernels.
6. Compare the estimates for different choices of bandwidth.
7. Is the estimate more influenced by the type of kernel or the bandwidth?


    df2 <- read.csv("http://www.faculty.ucr.edu/~jflegal/buffalo.txt")
    df2 <- as.numeric(df2[[1]])
    d1 <- density(df2, kernel = "epanechnikov")
    d2 <- density(df2, kernel = "gaussian")
    plot(d2, col="red", main="Kernel Density")
    lines(d1, col="blue")

![](unnamed-chunk-5-1.png)

***Problem 7***
===============

### Increasing the bandwidth for either kernel type smoothed out the plot and reduced the number of buckets appearing.

    d3 <- density(df2, kernel = "epanechnikov", bw=1)
    d4 <- density(df2, kernel = "epanechnikov", bw=9)
    d5 <- density(df2, kernel = "gaussian", bw = 1)
    d6 <- density(df2, kernel = "gaussian", bw = 9)
    plot(d5, col="red", main="Kernel Density", lty=3, xlab="")
    lines(d6, col="red", lty=1)
    lines(d4, col="darkgreen", lty=2, lwd=2)
    lines(d3, col="blue", lty=3)

![](unnamed-chunk-6-1.png)
