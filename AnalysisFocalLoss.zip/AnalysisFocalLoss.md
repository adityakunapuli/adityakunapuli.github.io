---
layout: page
title: Analysis
subtitle: Focal Loss for Dense Object Detection (RetinaNet)
---


<p class="myquote">
	This paper analyzes the novel implementation of a weighting factor to the loss function as outlined in the article "Focal Loss for Dense Object Detection" {% cite RetinaNet %} by Lin et al..  The author's coin the term "focal loss" for this weighting factor and its purpose is to modulate the effects of class imbalances in context of single-stage detectors. The analysis portion concludes by demonstrating that the performance of focal loss exceeded not only the current leading single-stage detection algorithms, but also leading two-stage algorithms as well.  The final section contains example images of the author's own implementation.
</p>

# Problem Statement
The primary motivation behind the introduction of focal loss is to improve performance of one-stage detectors, specifically in context of dealing with large class imbalances, a problem that two-stage detectors don't posses.  The specifics of the two families of detection algorithm is explored in detail below.


## Two Stage Detection
The problem of *object detection* fundamentally differs from *object classification* in that the purpose of the former is to detect the areas within an image that have a high probability of containing objects of interest.

The current state-of-the-art frameworks for object detection utilize a two stage process in which:
1. the first stage, utilizing a Region Proposal Network (RPN), generate sparse set of *region proposals* that cover Regions of Interest (ROI), and
2. the second stage, which utilizes a Convolutional Neural Network (CNN) to classify each proposal as either one of the foreground classes or as background.

The family of two-stage methodologies, such as R-CNN {% cite RCNN %}, Fast R-CNN {% cite fastRCNN %}, Faster R-CNN {% cite fasterRCNN %}, Mask R-CNN {% cite maskRCNN %} or some variants of these four archetypes, continue to demonstrate the highest average precision in COCO (AP COCO) evaluations {% cite COCOresults %}.

Though the most immediately apparent side-effect of two-stage models and their associated AP, is that they are also computationally demanding.  This can be attributed in large part to their requirement for very large input sizes, which in turns is a prerequisite for the ROI Pooling operations {% cite revisitRCNN %}.  The end result is the first stage produces a large number of candidate boundary boxes for each image, that is then fed into a CNN for classification.

<!-- %\begin{figure*}
%	\begin{center}
%		\fbox{\includegraphics[width=0.8\linewidth]{RCNNfamily.png}}
%		%		\frame{\includegraphics[width=0.8\linewidth]{RCNNfamily.png}}
%	\end{center}
%	\caption{Family of R-CNN Two-Stage Object Detectors @RCNNfamily.}
%	\label{fig:RCNNfam}
%\end{figure*}
%Figure~\ref{fig:RCNNfam} shows the architecture of the R-CNN family of two-stage detectors. -->

## Single Stage Detection
In comparison, a new family of object detectors that prioritizes speed over accuracy, has emerged and quickly gained popularity.  These models, called Single Shot Detectors (SSD), combine the process of boundary box prediction and classification into a single stage.

<style type="text/css">
   .analysis-tg  {
   border-collapse: collapse;
   margin-left: auto;
   margin-right: auto;
   border-top: 2px solid black;
   border-bottom: 2px solid black;
	 width: 50%;
   }
   .analysis-tg td{
	 background: white;
   padding:5px 10px;
   font-family:Arial, sans-serif;
   font-size:14px;
   border-style:solid;
   border-width:1px;
   border-color:black;
   background: white;
   border-left: 0px;
   border-right: 0px;
   }
   .analysis-tg th{
   padding:5px 10px;
   }
   .analysis-tg .analysis-tg-cell{
   text-align:left;
	 background: white;
   }
   .analysis-tg .analysis-tg-header{
   font-weight:bold;
   font-family: 'Arial Black', Gadget, sans-serif;
   text-align:left;
	 background: white;
	 border: 0px;
   }
</style>
<table class="analysis-tg">
   <tr>
      <th class="analysis-tg-header">Detector</th>
      <th class="analysis-tg-header">Backbone</th>
      <th class="analysis-tg-header">AP</th>
   </tr>
   <tr>
      <td class="analysis-tg-cell">YOLOv2</td>
      <td class="analysis-tg-cell">DarkNet-19</td>
      <td class="analysis-tg-cell">21.6</td>
   </tr>
   <tr>
      <td class="analysis-tg-cell">SSD513</td>
      <td class="analysis-tg-cell">ResNet-101-SSD</td>
      <td class="analysis-tg-cell">31.2</td>
   </tr>
   <tr>
      <td class="analysis-tg-cell">DSSD513</td>
      <td class="analysis-tg-cell">ResNet-101-DSSD</td>
      <td class="analysis-tg-cell">33.2</td>
   </tr>
</table>


As described, these models prioritize speed over accuracy, as such with the resulting decrease in computation time and computational resources, comes reduced performance.  The table above shows a performance comparison between the various Single Shot Detection models.Though nonetheless, there are many cases in which such a trade off is worth it, such as when used in consumer mobile devices.
<!-- As described, these models prioritize speed over accuracy, as such with the resulting decrease in computation time and computational resources, comes reduced performance.  Table~\ref{tbl:tbl1} shows a performance comparison between the various Single Shot Detection models.\origfootnote{For a much more thorough survey in performance differences between current architectures, see Ref~@googlereview. Figure~\ref{fig:accvtime} at the end of this analysis shows one of the results of the survey.}. Though nonetheless, there are many cases in which such a trade off is worth it, such as when used in consumer mobile devices. -->


A much more compelling problem arises in Single Stage Detectors--namely that of *class imbalance*.  Specifically, the *intrinsic imbalance* that arises in naturally occurring frequencies of data {% cite classimbalance %}--*e.g.* medical diagnoses of cancer in a large population of healthy patients.  In context of object detection models, Lin et al. summarized the problem as thus:
> These detectors evaluate $10^4-10^5$ candidate locations per image but only a few locations contain objects.
<!-- \begin{quotation}	\noindent
	These detectors evaluate $10^4-10^5$ candidate locations per image but only a few locations contain objects.
\end{quotation} -->

The issue of class imbalances and their effects on back-propagation algorithms within shallow neural nets has been documented and studied since at least the early 1990s.  Anand et al. showed that the effect of class imbalances led to the majority class dominating the net gradient {% cite Anand1993AnIA %}.  The figure below <!-- Figure~\ref{fig:Anand} --> demonstrates this--note that the error associated with the majority class quickly declines, whereas the error associated with the minority class essentially explodes until the model is *actually performing worse than simply flipping a coin*.  Or to put it another way: as a result of severe class imbalances, the model shown <!-- in Figure~\ref{fig:Anand} --> is performing so poorly in respect to the minority class, that actual prediction may be improved by reversing the assignment of probabilities (in a binary classification).

<!-- \begin{figure}[!htbp]
	\begin{center}
		\includegraphics[width=\linewidth]{Anand.png}
	\end{center}
	\caption{Effect of class imbalances. }
	\label{fig:Anand}
\end{figure} -->

<!-- ![](/assets/focalloss/Anand.png) -->
<!-- <img class="centerimg" style="width:75%;" src="/assets/focalloss/webp/Anand.webp"> -->

<figure  class="centerimg" style="width:75%;" >
  <figcaption style="text-align:center;">Effect of class imbalances. {% cite Anand1993AnIA %} </figcaption>
  <img src="{{site.url}}/assets/focalloss/webp/Anand.webp" alt=""/>
</figure>


# Approach
## Focal Loss
We begin by introducing the definition of $$\text{Cross Entropy (CE)}$$ loss in the case of binary classification:

$$
\begin{equation}
\text{CE}\left(p,y\right) =
\begin{cases}
-\log\left(p\right) & \text{if } y=1 \\
-\log\left(1-p\right) & \text{otherwise}
\end{cases}
\end{equation}
$$

Where $$y\in\left\{\pm 1\right\}$$ describes the ground truth class and $$p\in\left[0,1\right]$$ is the model's estimated probability for a given class with label $$y=1$$.  Rewriting the $$p$$ equation such that

$$
\begin{equation}
p_t=
\begin{cases}
p & \text{if } y=1 \\
1-p & \text{otherwise}
\end{cases}
\end{equation}
$$

Allows us to rewrite $\text{CE}$ such that:

$$
\begin{equation}
\text{CE}(p,y) = -\log{(p_t)}
\end{equation}
$$


To reiterate: the problem at hand is dealing with large classes imbalances in single step detectors.  Such imbalance overwhelm the cross-entropy loss; easy to classify negatives (*i.e.* easy negatives) end up contributing the majority of the loss and dominate the gradient.  In terms of medical diagnoses, this would be the equivalent of attempting to create a model for predicting cancer by studying a population of primarily cancer-free patients.  In such scenarios, the easy negatives (i.e. cancer-free patients) would end up defining the model.  Whereas, in reality we are truly interested in the population with cancer.

A method common in dealing with this class imbalance problem is the introduction of a weighting factor $$\alpha$$ to the cross-entropy loss function such that:

$$
\begin{equation}
\alpha_t=
\begin{cases}
\alpha & \text{if} y=1 \\
1-\alpha & \text{otherwise}
\end{cases}
\end{equation}
$$

Where $$\alpha\in\left[0,1\right]$$.  This modification of $$\text{CE}$$ is known as *balanced cross entropy*.  The addition of this weighting factor helps to balance the respective importance of positive and negative training examples

Utilizing the aforementioned example of modeling cancer, the introduction of $$\alpha$$ would now allow us to increase contributions to the model from the minority class (*i.e.* patients with cancer), while simultaneously decreasing the role of the majority class.

And while this is a step in the right direction, $$\alpha$$ makes no additional distinction in the contributions from easy and hard examples.

To deal with this inability to distinguish easy and hard samples, the author's introduced  a new factor in place of $$\alpha$$ called *focal loss*, which they defined as:

$$
\begin{equation}
\text{FL}(p_t)=-(1-p_t)^\gamma\log{(p_t)}
\end{equation}
$$

The coefficient $$-(1-p_t)^\gamma$$ is known as the *modulating factor*, where $$\gamma$$ is a tunable *focusing hyperparameter*.  Figure~\ref{fig:loss} shows how choice of $$\gamma$$ can influence loss.  Note that the case of $$\gamma=0$$ (*i.e.* the top-most line in blue) corresponds to the normal cross entropy loss function.


<img class="centerimg" style="width:75%;" src="/assets/focalloss/webp/CEloss.webp">


<!-- {% bibliography -c %} -->
